# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '0f94ec75271260df2141be8d14be711012e714cda985f73c3c10fee3f1f2a03da2314162eaedfa9a8c37a031ce3182730a49f47295d352acf99e58ff42b86137'